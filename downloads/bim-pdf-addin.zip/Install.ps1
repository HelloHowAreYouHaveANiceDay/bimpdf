# Install.ps1 -- Installs the bim-pdf Revit add-in.
# Auto-detects installed Revit versions (2025/2026) and installs the matching DLL for each,
# bundling the bim-pdf packer next to the DLL so packing works with no separate toolchain.
# Usage: .\Install.ps1 [-RevitYear 2025] [-Uninstall]
param(
    [int]   $RevitYear = 0,
    [switch]$Uninstall
)

$supportedYears = @(2025, 2026)
$scriptDir = $PSScriptRoot

function Get-InstalledRevitYears {
    $years = @()
    foreach ($y in $supportedYears) {
        if (Test-Path "HKLM:\SOFTWARE\Autodesk\Revit\$y") { $years += $y }
    }
    return $years
}

$installedYears = Get-InstalledRevitYears
if ($installedYears.Count -eq 0 -and -not $Uninstall) {
    Write-Error "No Revit installation detected in HKLM:\SOFTWARE\Autodesk\Revit\{2025,2026}"
    exit 1
}

$targetYears = if ($RevitYear -ne 0) { @($RevitYear) } else {
    if ($Uninstall) { $supportedYears } else { $installedYears }
}

foreach ($year in $targetYears) {
    $addinsRoot   = "$env:APPDATA\Autodesk\Revit\Addins\$year"
    $payloadDir   = "$addinsRoot\BimPdfAddin"
    $manifestPath = "$addinsRoot\BimPdfAddin.addin"

    if ($Uninstall) {
        Remove-Item -Path $manifestPath -Force -ErrorAction SilentlyContinue
        Remove-Item -Path $payloadDir   -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "Uninstalled from Revit $year"
        continue
    }

    if ($year -notin $installedYears) {
        Write-Warning "Revit $year not installed, skipping."
        continue
    }

    # Per-year DLL lives under revit<year>\ in the package.
    $dllSource = Join-Path $scriptDir "revit$year\BimPdfAddin.dll"
    if (-not (Test-Path $dllSource)) {
        Write-Warning "BimPdfAddin.dll for Revit $year not found at $dllSource, skipping."
        continue
    }

    New-Item -ItemType Directory -Path $payloadDir -Force | Out-Null

    # Deploy all managed DLLs for this year (BimPdfAddin.dll + PdfSharp.dll + deps).
    Copy-Item -Path (Join-Path $scriptDir "revit$year\*.dll") -Destination $payloadDir -Force
    $dllDest = "$payloadDir\BimPdfAddin.dll"

    $manifest = (Get-Content (Join-Path $scriptDir "BimPdfAddin.addin.template") -Raw) `
        -replace '\{ASSEMBLY_PATH\}', $dllDest
    $manifest | Set-Content -Path $manifestPath -Encoding UTF8

    Write-Host "Installed bim-pdf for Revit $year"
    Write-Host "  DLL:      $dllDest"
    Write-Host "  Manifest: $manifestPath"
}

Write-Host ""
Write-Host "Restart Revit to load the bim-pdf add-in."
